---
name: NexForge Industrial Framework
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#43474f'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#747780'
  outline-variant: '#c4c6d0'
  surface-tint: '#435f8d'
  primary: '#001939'
  on-primary: '#ffffff'
  primary-container: '#0b2e59'
  on-primary-container: '#7a97c8'
  inverse-primary: '#abc7fb'
  secondary: '#964900'
  on-secondary: '#ffffff'
  secondary-container: '#fc820c'
  on-secondary-container: '#5e2c00'
  tertiary: '#001d22'
  on-tertiary: '#ffffff'
  tertiary-container: '#00343c'
  on-tertiary-container: '#00a5ba'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#abc7fb'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#2a4773'
  secondary-fixed: '#ffdcc6'
  secondary-fixed-dim: '#ffb786'
  on-secondary-fixed: '#311300'
  on-secondary-fixed-variant: '#723600'
  tertiary-fixed: '#a1efff'
  tertiary-fixed-dim: '#44d8f1'
  on-tertiary-fixed: '#001f25'
  on-tertiary-fixed-variant: '#004e59'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Poppins
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Poppins
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.25'
  headline-lg-mobile:
    fontFamily: Poppins
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.25'
  headline-md:
    fontFamily: Poppins
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Poppins
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  mono-data:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  max-width: 1440px
---

## Brand & Style
The design system is engineered for high-stakes industrial automation and B2B enterprise environments. It prioritizes precision, reliability, and technical authority. The aesthetic is "Industrial Tech"—a blend of robust corporate stability and forward-thinking digital efficiency. 

The visual language utilizes a "Structured Modern" style: clean lines, generous but purposeful whitespace, and a high-contrast information hierarchy. It avoids decorative fluff in favor of functional clarity, drawing inspiration from high-end engineering interfaces (Siemens, ABB). The emotional response should be one of absolute control, safety, and real-time accuracy.

## Colors
The palette is rooted in **Industrial Blue**, providing a stable, professional foundation. **Automation Orange** is reserved strictly for primary actions and critical highlights to ensure high discoverability against the deep blue. **Electric Cyan** acts as a technical accent for data visualizations, active states, and "live" telemetry indicators.

- **Surface Strategy:** Use off-whites and cool grays for background layers to reduce eye strain during long shifts.
- **Contrast:** Ensure all text on colored backgrounds meets WCAG AA standards. Orange buttons should use white text for maximum punch.
- **Functional Color:** Use the tertiary Cyan for "Processing" or "Connected" states to distinguish from the primary "Action" Orange.

## Typography
This design system employs a dual-font strategy. **Poppins** brings a clean, geometric authority to headings, while **Inter** provides exceptional legibility for dense data and UI controls.

- **Data Density:** For technical readouts and serial numbers, an optional monospaced font (JetBrains Mono) is introduced to ensure character alignment.
- **Scalability:** Headings scale down significantly on mobile to maintain structural integrity in narrow viewports.
- **Labels:** Small labels use increased letter-spacing and uppercase styling to denote metadata and table headers.

## Layout & Spacing
The layout follows a strict **8px grid system** to ensure mathematical consistency. 

- **Grid:** A 12-column fluid grid is used for desktop (breakpoints at 1440px and 1200px), shifting to an 8-column grid for tablets (768px) and a 4-column grid for mobile (375px).
- **Density:** In dashboard views, the spacing can be compressed to "Compact" (base 4px) to allow more data on screen. For marketing or landing pages, "Standard" (base 8px) is preferred.
- **Containment:** Content is housed in structured panels with consistent internal padding of 24px (lg).

## Elevation & Depth
Elevation in the design system is conveyed through **Tonal Layers** and **Low-contrast Outlines** rather than heavy shadows. This maintains a "flat-tech" look that feels integrated with industrial hardware interfaces.

- **Level 0 (Background):** Neutral Gray (#F8F9FA).
- **Level 1 (Cards/Panels):** Pure White (#FFFFFF) with a 1px solid border (#E0E4E8). No shadow.
- **Level 2 (Dropdowns/Modals):** Pure White with a subtle, tight ambient shadow (0px 4px 12px rgba(11, 46, 89, 0.08)) to indicate temporary interaction.
- **State Changes:** Hover states on interactive elements use a subtle tint change or a 2px border accent rather than an elevation lift.

## Shapes
The design system uses a **Soft (0.25rem)** roundedness approach. This provides a professional, "machined" look—not as harsh as sharp 90-degree corners, but far more disciplined than overly rounded consumer apps.

- **Small Components:** Buttons, inputs, and tags use `rounded` (4px).
- **Large Components:** Cards, modals, and containers use `rounded-lg` (8px).
- **Special Case:** Status dots and notification badges remain perfectly circular.

## Components
Consistent implementation of these core components ensures a unified industrial experience:

- **Buttons:** 
  - *Primary:* Automation Orange background, white text, bold weight.
  - *Secondary:* Industrial Blue outline, Industrial Blue text. 
  - *Tertiary:* Ghost style (no border), Cyan text for technical toggles.
- **Input Fields:** 1px border (#E0E4E8), 12px horizontal padding. Active state uses a 1px Industrial Blue border with a soft Cyan outer glow.
- **Data Tables:** High-density, 40px row height. Headers are `label-md` with a light gray background (#F1F3F5).
- **Status Chips:** Small, rectangular with 2px radius. Use semantic colors: Green (Success), Orange (Warning), Blue (Info).
- **Cards:** White background, 1px border. Use a "Header Strip" (a 4px vertical line of color on the left edge) to denote category or status.
- **Lists:** Clean dividers (#F1F3F5), no bullets. Use 16px spacing between items.
- **Data Visualizations:** Use Electric Cyan as the primary data line, with Industrial Blue for axes and grid lines.